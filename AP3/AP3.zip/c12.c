#include <stdio.h>

int main()
{
    int x;
    if(x == 0) {
        printf("X is zero"); 
    }
    return 0;
}
